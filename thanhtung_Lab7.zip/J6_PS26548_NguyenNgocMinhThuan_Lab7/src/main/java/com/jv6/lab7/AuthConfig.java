package com.jv6.lab7;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import com.jv6.lab7.service.UserService;

@Configuration
@EnableWebSecurity
public class AuthConfig {
	@Autowired
	UserService userService;

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable()).cors(cors -> cors.disable())
				.authorizeHttpRequests((authorize) -> authorize.requestMatchers("/home/admins", "/authorize/index.html")
						.hasRole("ADMIN").requestMatchers("/home/users").hasAnyRole("ADMIN", "USER")
						.requestMatchers("/rest/authorities","/rest/authorities/**").hasAnyRole("ADMIN", "USER")
						.requestMatchers("/home/authenticated").authenticated().anyRequest().permitAll())
				.formLogin(formLogin -> formLogin.loginPage("/auth/login/form").loginProcessingUrl("/auth/login")
						.defaultSuccessUrl("/auth/login/success", false).failureUrl("/auth/login/error"))
				.oauth2Login(ou -> ou.authorizationEndpoint(e -> e.baseUri("/oauth2/authorization"))
						.loginPage("/auth/login/form").defaultSuccessUrl("/oauth2/login/success", true)
						.failureUrl("/auth/login/error"))
				.logout(logout -> logout.logoutUrl("/auth/logoff").logoutSuccessUrl("/auth/logoff/success"))
				.exceptionHandling(denied -> denied.accessDeniedPage("/auth/access/denied"));
		return http.build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}

	@Bean
	public BCryptPasswordEncoder getPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration auth) throws Exception {
		return auth.getAuthenticationManager();
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userService);
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

//	@Bean
//	public UserDetailsService userDetailsService() {
//		UserDetails userDetails = User.builder().username("user").password(passwordEncoder().encode("123"))
//				.roles("USER", "GUEST").build();
//		UserDetails userDetails2 = User.builder().username("admin").password(passwordEncoder().encode("123"))
//				.roles("ADMIN").build();
//
//		return new InMemoryUserDetailsManager(userDetails, userDetails2);
//	}
}
