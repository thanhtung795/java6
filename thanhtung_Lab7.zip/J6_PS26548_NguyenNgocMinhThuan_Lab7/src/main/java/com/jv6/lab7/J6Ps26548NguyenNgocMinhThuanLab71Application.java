package com.jv6.lab7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J6Ps26548NguyenNgocMinhThuanLab71Application {

	public static void main(String[] args) {
		SpringApplication.run(J6Ps26548NguyenNgocMinhThuanLab71Application.class, args);
	}

}
