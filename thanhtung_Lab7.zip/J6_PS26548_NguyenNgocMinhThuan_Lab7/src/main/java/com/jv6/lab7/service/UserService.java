package com.jv6.lab7.service;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.jv6.lab7.dao.AccountDAO;
import com.jv6.lab7.entity.Account;

@Service
public class UserService implements UserDetailsService {
	@Autowired
	AccountDAO accountDAO;
	
	PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		try {
			Account account = accountDAO.findById(username)
					.orElseThrow(() -> new UsernameNotFoundException(username + " not found"));

			// Ensure account is not null
			if (account == null) {
				throw new UsernameNotFoundException(username + " not found");
			}

			// Extract password
			String password = account.getPassword();

			// Extract roles and convert to array
			String[] roles = account.getAuthorities().stream().map(au -> au.getRole().getId()).toArray(String[]::new);
			return User.builder().username(account.getUsername()).password(encoder.encode(password)).roles(roles).build();
		} catch (UsernameNotFoundException e) {
			throw e; // Rethrow UsernameNotFoundException to propagate it up
		} catch (Exception e) {
			// Log the exception for debugging purposes
			throw new UsernameNotFoundException("Error occurred while loading user by username: " + username, e);
		}
	}


	public void loginFromOAuth2(OAuth2AuthenticationToken oauth2) {
		// TODO Auto-generated method stub
		String email = oauth2.getPrincipal().getAttribute("email");
		String password = Long.toHexString(System.currentTimeMillis());
		
		UserDetails user = User.builder().username(email).password(encoder.encode(password)).roles("GUEST").build();
		Authentication auth = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
		SecurityContextHolder.getContext().setAuthentication(auth);
	}

}
